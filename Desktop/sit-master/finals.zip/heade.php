<div style="background-color: ghostwhite;border-bottom: 1px solid black"><center><table style="width: 80%;height: 5%">
            <tr><td rowspan="3" ></td><td rowspan="3"><img src="../images/NIOT LOGO.png" height="100" width="100" style="background-color: white;"></td><td style="font-size: 30px; font-family: Century Schoolbook;;font-weight: bolder;color: black"><center>ACOUSTIC TEST FACILITY</center></td></tr>
                    <tr><td style="font-size: 30px; font-family: Century Schoolbook;;font-weight: bolder;color: black"><center>NATIONAL INSTITUTE OF OCEAN TECHNOLOGY</center></td></tr>
                    <tr><td ><center><h3 style="font-size: 20px; font-family: Century Schoolbook;;font-weight: bolder;" >LABORATORY QUALITY MANAGEMENT SYSTEM</h3></center></td></tr>
                    </table></center></div>
