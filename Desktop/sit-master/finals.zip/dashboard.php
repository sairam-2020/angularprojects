<html>
    <head>
         <link rel="stylesheet" href="sty.css"> 
    </head>
    <body>
        <?php 
        include './header.php';
        ?>
    </body>
</html>