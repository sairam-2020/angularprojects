  <div  ><center><table style="background-color: white;width: 100%;  ">
              <tr><td rowspan="2"><img src="../images/Logo.png"  width="100%"style="background-color: white;"></td><td style="font-size: 25px;font-family: century schoolbook ;font-weight: bolder;color: black"><center>SCIENCE AND HUMANITIES</center></td></tr>
                    <tr><td style="font-size: 23px;font-family: century schoolbook ;font-weight: bolder;color: black"><center>DEPARTMENT OF ENGLISH</center></td></tr>
                  </table></center></div>